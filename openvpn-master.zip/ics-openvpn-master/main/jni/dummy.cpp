/*#include <string>
#include <iostream>

void dummy()
{
    std::cout << "I am a dummy function to help compile on Android NDK r9" << std::endl;
}
*/
