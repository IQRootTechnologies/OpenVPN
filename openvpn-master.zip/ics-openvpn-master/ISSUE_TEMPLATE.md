To make issues more manageable, I would appreciate if you fill out the details if applicable

# General information
1. Android Version
2. Android Vendor/Custom ROM
3. Device
4. Version of the app (version number/play store version/self built)
 
# Description of the issue
 
 
 
